<?php 
session_start();
if(!empty($_SESSION['admin'])){
	require '../../config.php';
	if(!empty($_GET['kategori'])){
		$nama= $_POST['kategori'];
		$tgl= date("j F Y, G:i");
		$data[] = $nama;
		$data[] = $tgl;
		$sql = 'INSERT INTO kategori (nama_kategori,tgl_input) VALUES(?,?)';
		$row = $config -> prepare($sql);
		$row -> execute($data);
		echo '<script>window.location="../../index.php?page=kategori&&success=tambah-data"</script>';
	}
	if(!empty($_GET['barang'])){
		$id = $_POST['id'];
		$kategori = $_POST['kategori'];
		$nama = $_POST['nama'];
		$merk = $_POST['merk'];
		$beli = $_POST['beli'];
		$jual = $_POST['jual'];
		$satuan = $_POST['satuan'];
		$stok = $_POST['stok'];
		$tgl = $_POST['tgl'];
		
		$data[] = $id;
		$data[] = $kategori;
		$data[] = $nama;
		$data[] = $merk;
		$data[] = $beli;
		$data[] = $jual;
		$data[] = $satuan;
		$data[] = $stok;
		$data[] = $tgl;
		$sql = 'INSERT INTO barang (id_barang,id_kategori,nama_barang,merk,harga_beli,harga_jual,satuan_barang,stok,tgl_input) 
			    VALUES (?,?,?,?,?,?,?,?,?) ';
		$row = $config -> prepare($sql);
		$row -> execute($data);
		echo '<script>window.location="../../index.php?page=barang&success=tambah-data"</script>';
	}
	if(!empty($_GET['member'])){
		$nama = $_POST['nama'];
		$alamat = $_POST['alamat'];
		$telp = $_POST['telepon'];
		$email = $_POST['email'];
		$gambar = $_POST['gambar'];
		$nik = $_POST['nik'];
		
		$data[] = $id;
		$data[] = $nama;
		$data[] = $alamat;
		$data[] = $telp;
		$data[] = $email;
		$data[] = $gambar;
		$data[] = $nik;
		$sql = 'INSERT INTO member (nm_member,alamat_member,telepon,email,gambar,NIK) 
			    VALUES (?,?,?,?,?,?) ';
		$row = $config -> prepare($sql);
		$row -> execute($data);
		echo '<script>window.location="../../index.php?page=member&success=tambah-data"</script>';
	}
	if(!empty($_GET['login'])){
		$user = $_POST['user'];
		$pass = $_POST['pass'];
		$data[] = $user;
		$data[] = $pass;
		$sql = 'INSERT INTO login (user,pass=md5) VALUES(?,?)';
		$row = $config -> prepare($sql);
		$row -> execute($data);
		echo '<script>window.location="../../index.php?page=login&success=tambah-data"</script>';
	}
}