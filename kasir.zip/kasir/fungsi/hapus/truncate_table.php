<?php 
session_start();
if(!empty($_SESSION['admin'])){
	require '../../config.php';
    
}
?>